<?php 
require "../conection.php";
?>