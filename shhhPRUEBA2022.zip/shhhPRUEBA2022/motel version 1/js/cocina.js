/* document.getElementById("divClick").addEventListener("click",(e)=>{
    console.log(e)
    e.path[0].style.backgroundColor="#9ea714"
    e.path[0].style.Color="white"
    console.log(e.path[0])
})


function habitacionesBotones() {
    
}
 */



