<?php

if ("23:59:59"<date("H:i:s")) {
    echo "ok";
}else{
    echo "no ok";
}



?>