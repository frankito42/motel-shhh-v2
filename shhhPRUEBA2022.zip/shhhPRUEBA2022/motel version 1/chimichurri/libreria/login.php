<? // login parametrizable
$db_hostname = 'localhost';
$db_database = 'shhh';
$db_username = 'root';
$db_password = '';
?>